import { NAME } from './index';

it('NAME', () => {
  expect(NAME).toEqual('financial-management');
});
